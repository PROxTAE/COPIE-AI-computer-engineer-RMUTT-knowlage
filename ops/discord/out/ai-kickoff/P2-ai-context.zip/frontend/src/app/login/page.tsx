// Route /login — owner: P2 (user). Keep this file thin: render a component from the owning module.
export default function Page() {
  return (
    <main className="copie-ui">
      <div className="mx-auto flex max-w-2xl flex-col gap-3 px-4 py-16">
      <p className="copie-status">/login · P2 (user)</p>
      <h1 className="copie-heading text-4xl">เข้าสู่ระบบ</h1>
      <p className="text-cyber-muted">Continue with Google และ Dev Login</p>
      </div>
    </main>
  );
}
