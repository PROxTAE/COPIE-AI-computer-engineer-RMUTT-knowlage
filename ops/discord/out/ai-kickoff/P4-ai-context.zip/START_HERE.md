# COPIE — P4 เริ่มงานกับ AI

PR แรก: `rag/knowledge-v1` — Knowledge v1 + search stub

ตัวอย่างชื่อ PR: `data(rag): add verified department knowledge` · base `develop` · reviewer P3

## วิธีใช้

1. clone/pull โปรเจกต์และเปิด AI ในโฟลเดอร์ repo; แตก ZIP นี้เพื่อดูไฟล์ทั้งหมดตาม path เดิม
2. ถ้า AI เข้าถึง repo ได้ ให้ระบุ path เหล่านี้ให้อ่าน; ถ้าเป็นแชตที่ไม่มี repo ให้แนบไฟล์ใน ZIP เป็นรายไฟล์ โดยเฉพาะ .md, contract และภาพ .png (ZIP อย่างเดียวบาง AI อ่านไม่ได้)
3. คัดลอก PROMPT_FOR_AI.txt ไปสั่ง AI ให้ทำต่อเนื่องตาม Phase จนจบงาน โดยแบ่งผลเป็น PR เล็กและเช็กหลังแต่ละ slice
4. ตรวจ diff และผล test เอง; commit/push/เปิด PR เข้า develop เองตาม 00_GIT_DELIVERY_RULES.md ภายในอาทิตย์ 27 ก.ย. 2026
5. ไฟล์ใน ZIP เป็น snapshot สำหรับบริบท ณ วันที่จัดชุด; ตรวจ develop ล่าสุดก่อนลงมือ และอย่าอัปโหลด .env หรือ token

## ไฟล์ในชุดนี้

- `IMPLEMENTATION_PLANS/00_SHARED_PROJECT_CONTEXT.md`
- `IMPLEMENTATION_PLANS/00_API_AND_DATA_CONTRACTS.md`
- `IMPLEMENTATION_PLANS/00_GIT_DELIVERY_RULES.md`
- `IMPLEMENTATION_PLANS/00_TIMELINE_AND_SYNC.md`
- `IMPLEMENTATION_PLANS/AI_EXECUTION_INSTRUCTIONS.md`
- `IMPLEMENTATION_PLANS/PR_TEMPLATE.md`
- `IMPLEMENTATION_PLANS/09_INTEGRATION_ACCEPTANCE_RUNBOOK.md`
- `frontend/src/types/contract.ts`
- `backend/app/schemas/contract.py`
- `docs/diagrams/copie-handoff-flow.png`
- `IMPLEMENTATION_PLANS/04_DEPARTMENT_RAG.md`
- `backend/app/modules/rag/README.md`
- `data/knowledge/README.md`
- `resource/RMUTT_CE_AI_Project_Summary_COPIE.md`
- `backend/requirements.txt`
