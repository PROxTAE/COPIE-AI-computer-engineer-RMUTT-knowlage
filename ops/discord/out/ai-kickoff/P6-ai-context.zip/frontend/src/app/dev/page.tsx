// Route /dev — owner: P6 (renderer). Keep this file thin: render a component from the owning module.
export default function Page() {
  return (
    <main className="copie-ui">
      <div className="mx-auto flex max-w-2xl flex-col gap-3 px-4 py-16">
      <p className="copie-status">/dev · P6 (renderer)</p>
      <h1 className="copie-heading text-4xl">Renderer playground</h1>
      <p className="text-cyber-muted">แสดง mock ของทุก response_type โดยไม่ต้องมี backend</p>
      </div>
    </main>
  );
}
