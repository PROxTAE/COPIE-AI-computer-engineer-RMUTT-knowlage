# COPIE Web UI Asset Kit — White Cyberism

ชุดไฟล์แยกส่วนจากทิศทางภาพ [UI Flow](../mockups/ui-flow-v1/SCREEN_GUIDE.md) สำหรับนำไปประกอบเว็บจริง ไฟล์ภาพ mockup ใช้เป็นแบบอ้างอิง ส่วนชุดนี้มีองค์ประกอบที่นำกลับมาใช้ซ้ำได้และปรับตามขนาดหน้าจอได้

## โครงสร้างโฟลเดอร์

| โฟลเดอร์ | ไฟล์ | ใช้ทำอะไร |
| --- | --- | --- |
| [brand](brand/) | copie-mark.svg, favicon.svg | เครื่องหมาย COPIE ขนาดเล็กและไอคอนแท็บเบราว์เซอร์ |
| [backgrounds](backgrounds/) | grid-light.svg | เส้นกริดฟ้าจางบนพื้นขาว |
| [backgrounds](backgrounds/) | floor-perspective.svg | เส้นพื้นลึกเฉพาะหน้าที่มาสคอตเป็นจุดเด่น |
| [backgrounds](backgrounds/) | mascot-halo.svg | วงแสงโปร่งใสหลังมาสคอต |
| [backgrounds](backgrounds/) | cyan-wash.svg | สีฟ้าอ่อนช่วงล่างของหน้าจอ |
| [frames](frames/) | corner-accent.svg | มุมเส้นสีฟ้าสำหรับกรอบพื้นที่คำตอบ หมุนใช้ได้ทั้งสี่มุม |
| [frames](frames/) | response-rule.svg | เส้นคั่นและแถบเน้นใต้หัวข้อคำตอบ |
| [frames](frames/) | side-rail.svg | เส้นแบ่งแถบด้านขวาในโหมดอ่าน ตาราง การ์ด และ Radar |
| [effects](effects/) | data-streak.svg | เส้นแสงสั้นหลังหัวข้อขณะคำตอบปรากฏ |
| [effects](effects/) | signal-dots.svg | ลายจุดสำหรับพื้นที่เล็ก ๆ ไม่ควรปูทั้งหน้า |
| [icons](icons/) | SVG 21 ชิ้น | โปรไฟล์ History ส่งข้อความ ค้นหา นำทาง แหล่งอ้างอิง Feedback และปุ่มอื่น ๆ |
| [mascot/states](mascot/states/) | PNG โปร่งใส 8 ท่า | สถานะ idle, listening, thinking, responding, success, no-answer, skill-guide และภาพหน้าตรงถือแล็ปท็อป |
| [mascot/3d](mascot/3d/) | copie-mascot-web.glb | โมเดล 3D ของโปรเจกต์สำหรับหน้าที่ใช้ Three.js |
| [styles](styles/) | tokens.css, copie-ui.css, motion.css | สี ฟอนต์ กรอบ ช่องพิมพ์ ปุ่ม และแอนิเมชันที่เคารพ reduced motion |

ไฟล์ [manifest.json](manifest.json) เป็นรายการไฟล์สำหรับงานพัฒนา และ [preview.html](preview.html) เป็นหน้าเปิดดูองค์ประกอบของชุดนี้

## การเลือกใช้ตามหน้าจอ

| บริบท | องค์ประกอบหลัก |
| --- | --- |
| Login / Onboarding | grid-light.svg, cyan-wash.svg, มาสคอต PNG หน้าตรง; ไม่แสดงไอคอนโปรไฟล์หรือ History ก่อนเข้าสู่ระบบ |
| แชตขณะพิมพ์ | มาสคอตกลางจอ, mascot-halo.svg, floor-perspective.svg, ช่องพิมพ์, history.svg, profile.svg, send.svg |
| AI ตอบกลับ | เพิ่ม response-rule.svg และ data-streak.svg เฉพาะหัวข้อ; คำตอบยังเป็น HTML/ข้อความจริง |
| โหมดอ่านเต็ม | มาสคอตย่อไปแถบขวา, side-rail.svg, ไอคอน eye-off, copy, thumb-up, thumb-down, document |
| History | แผงลอย HTML/CSS กับไอคอน history, search, close, menu; รายการมาจากประวัติจริง |
| ตารางรายวิชา / การ์ด | ใช้เส้นและกรอบ CSS, มาสคอตขนาดเล็ก; ตารางและการ์ดสร้างจากข้อมูลจริง |
| แบบประเมิน | ใช้ฟอร์ม HTML ที่กดได้จริง, มาสคอตขนาดเล็กระหว่างตอบ; response-rule.svg ใช้กับหัวข้อ |
| Skill Radar | สร้างกราฟจากคะแนนจริงด้วย chart component, ใช้มาสคอตและเส้นตกแต่งจากชุดนี้ |

## วิธีใช้ในเว็บ

1. วางโฟลเดอร์ brand, backgrounds, frames, effects, icons, mascot ไว้ใต้ frontend/public/copie-ui/ เพื่ออ้างด้วย URL เช่น /copie-ui/icons/history.svg
2. นำไฟล์ใน styles/ เข้าสู่ CSS ของ frontend โดยคงโครงสร้างโฟลเดอร์เดียวกัน หรือแก้ URL ภายใน CSS ให้ตรงกับตำแหน่งที่วางจริง
3. ใช้ copie-ui เป็น class ของพื้นที่หน้าจอที่ใช้ธีมนี้ แล้วเลือก class ย่อย เช่น copie-halo, copie-input, copie-button, copie-mascot
4. สำหรับไอคอนที่ต้องเปลี่ยนสีด้วย CSS ให้นำ SVG ไปใช้แบบ inline หรือ CSS mask; SVG แต่ละไฟล์ใช้ currentColor
5. ใช้ PNG มาสคอตเป็นภาพโปร่งใสหรือ GLB ตามวิธีเรนเดอร์ที่เลือก สถานะของมาสคอตควรสอดคล้องกับ idle, listening, thinking, responding, success

ตัวอย่างโครง HTML ขั้นต่ำ:

    <main class="copie-ui">
      <div class="copie-floor"></div>
      <div class="copie-halo"></div>
      <img class="copie-mascot" src="/copie-ui/mascot/states/copie-front-laptop.png" alt="COPIE" />
    </main>

## กติกาการประกอบ UI

- เว้นพื้นขาวให้มากกว่าพื้นที่ตกแต่ง เส้นกริด วงแสง และ data streak ใช้อย่างเบา
- รักษาลำดับภาพ: มาสคอตใหญ่กลางจอในหน้าแชต; ย่อหรือซ่อนเมื่อเนื้อหาต้องใช้พื้นที่
- ปุ่มและช่องกรอกควรเป็น HTML จริงพร้อม focus state
- ข้อความตอบ แหล่งอ้างอิง ตาราง การ์ด แบบประเมิน และกราฟต้องเรนเดอร์จากข้อมูลจริง
- CSS ในชุดนี้มี prefers-reduced-motion เพื่อหยุดแอนิเมชันเมื่อผู้ใช้ตั้งค่าลดการเคลื่อนไหว

PNG มาสคอตมาจาก assets/mascot/states/ และ GLB มาจาก frontend/public/models/ ในโปรเจกต์เดียวกัน ไฟล์ SVG/CSS ชุดนี้สร้างเป็นองค์ประกอบใหม่ตามภาพต้นแบบ
