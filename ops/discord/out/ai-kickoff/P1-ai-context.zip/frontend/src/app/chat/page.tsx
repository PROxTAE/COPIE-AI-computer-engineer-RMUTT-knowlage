import { Copie } from "@/modules/mascot";

// Route /chat — owner: P1 (core). This remains a placeholder for the chat workspace.
export default function Page() {
  return (
    <main className="mx-auto flex max-w-3xl flex-col items-center gap-3 px-4 py-10 text-center">
      <h1 className="copie-heading text-4xl">คุยกับ COPIE</h1>
      <p className="text-cyber-muted">ผู้ช่วย AI ของภาควิชาวิศวกรรมคอมพิวเตอร์ RMUTT</p>
      <div className="mt-2 h-[min(65vh,580px)] w-full max-w-xl">
        <Copie state="idle" label="COPIE 3D ถือแล็ปท็อป" />
      </div>
      <p className="copie-status">ระบบแชตกำลังอยู่ระหว่างการพัฒนา</p>
    </main>
  );
}
