# COPIE — P1 เริ่มงานกับ AI

PR แรก: `core/white-cyberism-theme` — ธีม White Cyberism + มาสคอต

ตัวอย่างชื่อ PR: `style(core): add white cyberism theme` · base `develop` · reviewer P6

## วิธีใช้

1. clone/pull โปรเจกต์และเปิด AI ในโฟลเดอร์ repo; แตก ZIP นี้เพื่อดูไฟล์ทั้งหมดตาม path เดิม
2. ถ้า AI เข้าถึง repo ได้ ให้ระบุ path เหล่านี้ให้อ่าน; ถ้าเป็นแชตที่ไม่มี repo ให้แนบไฟล์ใน ZIP เป็นรายไฟล์ โดยเฉพาะ .md, contract และภาพ .png (ZIP อย่างเดียวบาง AI อ่านไม่ได้)
3. คัดลอก PROMPT_FOR_AI.txt ไปสั่ง AI ให้ทำต่อเนื่องตาม Phase จนจบงาน โดยแบ่งผลเป็น PR เล็กและเช็กหลังแต่ละ slice
4. ตรวจ diff และผล test เอง; commit/push/เปิด PR เข้า develop เองตาม 00_GIT_DELIVERY_RULES.md ภายในอาทิตย์ 27 ก.ย. 2026
5. ไฟล์ใน ZIP เป็น snapshot สำหรับบริบท ณ วันที่จัดชุด; ตรวจ develop ล่าสุดก่อนลงมือ และอย่าอัปโหลด .env หรือ token

## ไฟล์ในชุดนี้

- `IMPLEMENTATION_PLANS/00_SHARED_PROJECT_CONTEXT.md`
- `IMPLEMENTATION_PLANS/00_API_AND_DATA_CONTRACTS.md`
- `IMPLEMENTATION_PLANS/00_GIT_DELIVERY_RULES.md`
- `IMPLEMENTATION_PLANS/00_TIMELINE_AND_SYNC.md`
- `IMPLEMENTATION_PLANS/AI_EXECUTION_INSTRUCTIONS.md`
- `IMPLEMENTATION_PLANS/PR_TEMPLATE.md`
- `IMPLEMENTATION_PLANS/09_INTEGRATION_ACCEPTANCE_RUNBOOK.md`
- `frontend/src/types/contract.ts`
- `backend/app/schemas/contract.py`
- `docs/diagrams/copie-handoff-flow.png`
- `IMPLEMENTATION_PLANS/01_FRONTEND_CORE_MASCOT.md`
- `frontend/package.json`
- `frontend/src/app/chat/page.tsx`
- `frontend/src/app/globals.css`
- `frontend/src/modules/core/README.md`
- `frontend/src/modules/core/theme/theme.css`
- `frontend/src/modules/mascot/README.md`
- `frontend/src/modules/mascot/CopieMascot.tsx`
- `frontend/src/modules/mascot/states.ts`
- `assets/web-ui/ASSET_GUIDE.md`
- `assets/web-ui/styles/tokens.css`
- `assets/mockups/ui-flow-v1/SCREEN_GUIDE.md`
- `assets/mockups/ui-flow-v1/03-chat-composing.png`
- `assets/mockups/ui-flow-v1/04-chat-answer.png`
- `assets/mockups/ui-flow-v1/05-reading-mode.png`
- `assets/mockups/ui-flow-v1/11-skill-radar.png`
- `assets/web-ui/mascot/states/copie-front-laptop.png`
- `assets/web-ui/mascot/states/copie-idle.png`
- `assets/web-ui/mascot/states/copie-thinking.png`
- `assets/web-ui/mascot/states/copie-responding.png`
